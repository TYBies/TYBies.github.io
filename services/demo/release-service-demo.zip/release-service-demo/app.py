"""Disposable release-check sample. Not a production HTTP server."""
import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer


def payload(version: str) -> dict:
    """Return the versioned contract; broken deliberately violates it."""
    return {"version": version, "status": "unhealthy" if version == "broken" else "ok"}


class Handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        if self.path != "/health":
            self.send_error(404)
            return
        body = json.dumps(payload(os.getenv("APP_VERSION", "v1"))).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    HTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
